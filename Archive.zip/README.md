# RISCV-simulator
this is a riscv simulator project
